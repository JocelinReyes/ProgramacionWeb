package analizara;

import javax.swing.*;
import java.awt.*;

public class loginPrueba extends JFrame {
    private JTextField nameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton signUpButton;

    public loginPrueba() {
        setTitle("Create Account");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel principal
        JPanel mainPanel = new JPanel(new BorderLayout());
        add(mainPanel);

        // Panel izquierdo (Imagen)
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(new Color(172, 228, 231));
        ImageIcon icon = new ImageIcon("C:\\Users\\Jocelin\\Documents\\NetBeansProjects\\lexicoPruebas\\src\\img\\login2.gif");
        JLabel illustrationLabel = new JLabel(icon, SwingConstants.CENTER);
        leftPanel.add(illustrationLabel, BorderLayout.CENTER);
        mainPanel.add(leftPanel, BorderLayout.WEST);

        // Panel derecho (Formulario)
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);
        mainPanel.add(rightPanel, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        JLabel titleLabel = new JLabel("Analizador Lexico", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        rightPanel.add(titleLabel, gbc);

        // Campos del formulario
        agregarCampo(rightPanel, gbc, "Name:", 1);
        nameField = new JTextField(15);
        rightPanel.add(nameField, gbc);


        agregarCampo(rightPanel, gbc, "Password:", 3);
        passwordField = new JPasswordField(15);
        rightPanel.add(passwordField, gbc);

        // Botón
        signUpButton = new JButton("SIGN UP");
        signUpButton.setBackground(new Color(172, 228, 231));
        signUpButton.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        rightPanel.add(signUpButton, gbc);

        signUpButton.addActionListener(e -> autenticar());
    }

    private void agregarCampo(JPanel panel, GridBagConstraints gbc, String etiqueta, int fila) {
        JLabel label = new JLabel(etiqueta);
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = fila;
        panel.add(label, gbc);
        gbc.gridx = 1;
    }

    private void autenticar() {
        String name = nameField.getText();
        String password = new String(passwordField.getPassword());

        if (name.equals("admin") && password.equals("12345")) {
            JOptionPane.showMessageDialog(this, "Login exitoso");
            new INTERFA().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new loginPrueba().setVisible(true));
    }
}




