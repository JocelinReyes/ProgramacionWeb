/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package analizara;

/**
 *
 * @author Jocelin
 */

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.TimeUnit;

public class splash{


    public static void main(String[] args) {
        // Crea una nueva ventana JFrame para el Splash Screen
        JFrame splashFrame = new JFrame("Splash Screen");
        
        // Crea un panel que contenga un mensaje o imagen
        JPanel splashPanel = new JPanel();
        splashPanel.setLayout(new BorderLayout());
        
         splashPanel.setBackground(Color.BLACK); 
        
        // Usamos una etiqueta JLabel para mostrar un mensaje o logo
        JLabel splashLabel = new JLabel("Bienvenidos a...", JLabel.CENTER);
        splashLabel.setFont(new Font("Eras Demi ITC", Font.BOLD, 20));
        splashLabel.setForeground(Color.WHITE);
        splashPanel.add(splashLabel, BorderLayout.CENTER);
        
        // Personaliza el JFrame (hacerlo transparente, sin bordes, etc.)
        splashFrame.setUndecorated(true); // Sin borde
        splashFrame.setSize(400, 200); // Tamaño de la pantalla de inicio
        splashFrame.setLocationRelativeTo(null); // Centra la ventana en la pantalla
        splashFrame.getContentPane().add(splashPanel);
        
        // Muestra el Splash Screen
        splashFrame.setVisible(true);
        
        // Simula la carga de la aplicación (espera 3 segundos)
        try {
            TimeUnit.SECONDS.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Cierra el Splash Screen después de la espera
        splashFrame.dispose();
        
        // Aquí comienza la aplicación principal
        launchMainApplication();
    }

    public static void launchMainApplication() {
        // Crear y mostrar la ventana principal de la aplicación
        loginPrueba loginFrame = new loginPrueba();
        loginFrame.setVisible(true);
    }
    static class SplashPanel extends JPanel {
        private int angle = 0; // Ángulo inicial de la animación

        public SplashPanel() {
            // Usamos un Timer para animar el círculo de carga
            Timer timer = new Timer(50, e -> {
                angle += 5;
                if (angle >= 360) {
                    angle = 0; // Reseteamos el ángulo
                }
                repaint(); // Redibuja el panel
            });
            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Dibuja el círculo de carga
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Dibuja un círculo vacío
            g2d.setColor(Color.WHITE);
            g2d.setStroke(new BasicStroke(5));
            g2d.drawArc(150, 50, 100, 100, 0, angle); // Círculo animado

            // Crea un círculo de carga giratorio
            g2d.setStroke(new BasicStroke(5));
            g2d.setColor(Color.RED);
            g2d.drawArc(150, 50, 100, 100, angle, 270); // El arco que representa la carga
        }
    }
   
}

