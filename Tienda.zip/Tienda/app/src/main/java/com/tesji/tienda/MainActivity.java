package com.tesji.tienda;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


import com.google.android.material.textfield.TextInputEditText;
import com.tesji.tienda.model.CarrerasModel;
public class MainActivity extends AppCompatActivity{
    private Spinner spClientes;
    private TextInputEditText txMonto;
    private Spinner spPago;
    private TextView tvImprimir;
    String[] opCliente= {
            "--Seleccione un cliente",
            "Cliente general",
            "Cliente Afiliado"};
    String[] opPago={
            "--Seleccione un tipo de pago",
            "Contado",
            "Plazos"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        spClientes = findViewById(R.id.sppinnerCliente);
        spPago = findViewById(R.id.sppinnerPago);
        txMonto = findViewById(R.id.txtPagar);
        tvImprimir = findViewById(R.id.textViewImprimir);
        ArrayAdapter<String> adapCli = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,opCliente);
        ArrayAdapter<String> adapPag = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,opPago);
        spClientes.setAdapter(adapCli);
        spPago.setAdapter(adapPag);
        spPago.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CarrerasModel pago =new CarrerasModel();
                pago.setPago(spPago.getSelectedItemPosition());
                pago.setPagar(Integer.parseInt(txMonto.getText().toString()));
                pago.setCliente(spClientes.getSelectedItemPosition());
                tvImprimir.setText(pago.montoTotal());

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}