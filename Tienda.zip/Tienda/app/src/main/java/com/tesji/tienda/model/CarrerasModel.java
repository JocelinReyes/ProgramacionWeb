package com.tesji.tienda.model;


public class CarrerasModel {
    private float Pagar;
    private int Cliente;
    private int Pago;


    public String montoTotal() {
        String pagoFinal = "";
        double a = 0.15, b = 0.20, c = 0.10, d = 0.5, t, res;
        if (Cliente == 0 && Pago == 0) {
            pagoFinal = "Porfavor seleccione una opcion";

        } else if (Cliente == 1 && Pago == 1) {
            t = Pagar * a;
            res = Pagar - t;
            pagoFinal = "Tu descuento es de: " + t + "\nTu total a pagar es: " + res;
        } else if (Cliente == 1 && Pago == 2) {
            t = Pagar * c;
            res = Pagar + t;
            pagoFinal = "Tu aumento es de: " + t + "\nTu total a pagar es: " + res;

        } else if (Cliente == 2 && Pago == 1) {
            t = Pagar * b;
            res = Pagar - t;
            pagoFinal = "Tu descuento es de: " + t + "\nTu total a pagar es: " + res;
        } else if (Cliente == 2 && Pago == 2) {
            t = Pagar * d;
            res = Pagar + t;
            pagoFinal = "Tu aumento es de: " + t + "\nTu total a pagar es: " + res;
        }
        return pagoFinal;
    }

    public float getPagar() {return Pagar;}

    public void setPagar(float pagar) {Pagar = pagar;}

    public int getCliente() {return Cliente;}

    public void setCliente(int cliente) {Cliente = cliente;}

    public int getPago() {return Pago;}

    public void setPago(int pago) {Pago = pago;}
}