package com.tesji.doubledashclock.model;

public class MainActivityModel {
    private int minutos1;
    private int segundos1;
    private int minutos2;
    private int segundos2;


    public int getMinutos1() {
        return minutos1;
    }

    public void setMinutos1(int minutos1) {
        this.minutos1 = minutos1;
    }

    public int getSegundos1() {
        return segundos1;
    }

    public void setSegundos1(int segundos1) {
        this.segundos1 = segundos1;
    }

    public int getMinutos2() {
        return minutos2;
    }

    public void setMinutos2(int minutos2) {
        this.minutos2 = minutos2;
    }

    public int getSegundos2() {
        return segundos2;
    }

    public void setSegundos2(int segundos2) {
        this.segundos2 = segundos2;
    }

    public String calcularTiempo() {

        if(minutos1<=0 || minutos2<=0 || segundos1>=60 || segundos2>=60){
            return "Ingresa valores que esten dentro del rango correcto";
        }else {
            int horas = 0;
            int minutos = 0;
            int segundos = 0;
            int totalminutos = minutos1 + minutos2;
            int totalsegundos = segundos1 + segundos2;

            if (totalsegundos >= 60) {
                totalminutos += totalsegundos / 60;
                totalsegundos %= 60;
            }
            horas = totalminutos / 60;
            minutos = totalminutos % 60;
            segundos = totalsegundos;


            return "El tiempo total es de \n" + horas + " horas " +
                    minutos + " minutos " +
                    segundos + " segundos ";
        }
    }
}
