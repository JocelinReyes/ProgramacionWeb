package com.tesji.doubledashclock;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.tesji.doubledashclock.model.MainActivityModel;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText txMinutos1;
    private TextInputEditText txSegundos1;
    private TextInputEditText txMinutos2;
    private TextInputEditText txSegundos2;
    private AppCompatButton btEnviar;
    private Button btLimpiar;
    private Button btSalir;
    private MediaPlayer sonidoBoton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txMinutos1 = findViewById(R.id.txtMinutos1);
        txSegundos1 = findViewById(R.id.txtSegundos1);
        txMinutos2 = findViewById(R.id.txtMinutos2);
        txSegundos2 = findViewById(R.id.txtSegundos2);
        btEnviar = findViewById(R.id.btnEnviar);
        btLimpiar = findViewById(R.id.btnLimpiar);
        btSalir = findViewById(R.id.btnSalir);

        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sonidoBoton = MediaPlayer.create(getApplicationContext(),R.raw.dobleclick);
                sonidoBoton.start();
                //int segundos1 = Integer.parseInt(txSegundos1.getText().toString());
                //int segundos2 = Integer.parseInt(txSegundos2.getText().toString());

                if(txMinutos1.getText().toString().trim().length()==0){
                    txMinutos1.setText("");
                    txMinutos1.setError("Debe ingresar los minutos del atleta 1");
                    txMinutos1.requestFocus();
                }else if (txSegundos1.getText().toString().trim().length()==0) {
                    txSegundos1.setText(null);
                    txSegundos1.setError("Debe ingresar los segundos del atleta 1");
                    txSegundos1.requestFocus();
                }else if (txMinutos2.getText().toString().trim().length()==0) {
                    txMinutos2.setText(null);
                    txMinutos2.setError("Debe ingresar los segundos del atleta 2");
                    txMinutos2.requestFocus();
                }else if (txSegundos2.getText().toString().trim().length()==0) {
                    txSegundos2.setText(null);
                    txSegundos2.setError("Debe ingresar los segundos del atleta 2");
                    txSegundos2.requestFocus();
                } /*else if (segundos1 > 60) {
                    txSegundos1.setError("Los segundos deben de ser menores a 60");
                    txSegundos1.requestFocus();
                }else if (segundos2 > 60) {
                    txSegundos2.setError("Los segundos deben de ser menores a 60");
                    txSegundos2.requestFocus();
                }*/ else {
                    MainActivityModel objModel=new MainActivityModel();
                    objModel.setMinutos1(Integer.parseInt(txMinutos1.getText().toString()));
                    objModel.setMinutos2(Integer.parseInt(txMinutos2.getText().toString()));
                    objModel.setSegundos1(Integer.parseInt(txSegundos1.getText().toString()));
                    objModel.setSegundos2(Integer.parseInt(txSegundos2.getText().toString()));
                    Toast.makeText(getApplicationContext(),
                            objModel.calcularTiempo(),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        btLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txMinutos1.setText("");
                txSegundos1.setText("");
                txMinutos2.setText("");
                txSegundos2.setText("");
            }
        });
        btSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}