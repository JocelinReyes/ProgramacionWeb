package codigo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Principal {
    public static void main(String[] args) {
        try {
            // Rutas originales
            String ruta1 = "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/src/codigo/Lexer.flex";
            String ruta2 = "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/src/codigo/LexerCup.flex";
            String[] rutaS = {
                "-parser", "Sintax", 
                "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/src/codigo/Sintax.cup"
            };

            // Generar analizadores
            generar(ruta1, ruta2, rutaS);

            System.out.println("Analizadores generados exitosamente.");

        } catch (Exception e) {
            System.err.println("Error durante la generación de analizadores: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void generar(String ruta1, String ruta2, String[] rutaS) throws IOException {
        try {
            // Generar analizador léxico con JFlex
            File archivo = new File(ruta1);
            if (archivo.exists()) {
                JFlex.Main.generate(archivo);
            } else {
                throw new IOException("Archivo no encontrado: " + ruta1);
            }

            archivo = new File(ruta2);
            if (archivo.exists()) {
                JFlex.Main.generate(archivo);
            } else {
                throw new IOException("Archivo no encontrado: " + ruta2);
            }

            // Generar analizador sintáctico con JavaCUP
            java_cup.Main.main(rutaS);

            // Mover archivos generados
            moverArchivo(
                "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/sym.java",
                "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/src/codigo/sym.java"
            );

            moverArchivo(
                "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/Sintax.java",
                "C:/Users/Jocelin/Documents/NetBeansProjects/AnalizadorLexico - copia/src/codigo/Sintax.java"
            );
        } catch (java_cup.internal_error e) {
            throw new RuntimeException("Error interno en JavaCUP: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new RuntimeException("Error inesperado: " + e.getMessage(), e);
        }
    }

    private static void moverArchivo(String archivoOrigen, String archivoDestino) throws IOException {
        Path origen = Paths.get(archivoOrigen);
        Path destino = Paths.get(archivoDestino);

        // Verifica si el archivo de destino ya existe y elimínalo
        if (Files.exists(destino)) {
            Files.delete(destino);
        }

        // Asegúrate de que el directorio de destino exista
        if (!Files.exists(destino.getParent())) {
            Files.createDirectories(destino.getParent());
        }

        // Mueve el archivo generado
        Files.move(origen, destino);
        System.out.println("Archivo movido: " + archivoOrigen + " -> " + archivoDestino);
    }
}
