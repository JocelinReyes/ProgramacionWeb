package codigo;  

import javax.swing.*;
import java.awt.*;

public class creditos extends JFrame {

    public creditos() {
        // Configuración de la ventana
        setTitle("Créditos de la Aplicación");
        setSize(400, 300);
        setLocationRelativeTo(null); // Centra la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Crear un panel con fondo negro
        JPanel panel = new JPanel();
        panel.setBackground(Color.BLACK);  // Fondo negro
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));  // Layout de caja vertical

        // Título en cian
        JLabel title = new JLabel("Créditos", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(Color.CYAN);
        panel.add(title);

        // Texto con los créditos de la aplicación
        JTextArea creditosText = new JTextArea();
        creditosText.setText("Aplicación creada por:\n" +
                             "Fabiola Castañeda Mondragon\n" +
                             "Antonio García Noguez\n" +
                             "Williams\n" +
                             "Diana Gi\n" +
                             "Jocelin Reyes Rodriguez\n" +
                             "Agradecemos a todos los usuarios que han probado la aplicación.");
        creditosText.setBackground(Color.BLACK);  // Fondo negro
        creditosText.setForeground(Color.CYAN);   // Texto en cian
        creditosText.setFont(new Font("Arial", Font.PLAIN, 14));
        creditosText.setEditable(false);          // No editable
        creditosText.setLineWrap(true);           // Ajuste de línea
        creditosText.setWrapStyleWord(true);      // Ajuste por palabra
        JScrollPane scrollPane = new JScrollPane(creditosText);  // Panel de desplazamiento
        panel.add(scrollPane);

        // Botón de cerrar
        JButton closeButton = new JButton("Cerrar");
        closeButton.setBackground(Color.CYAN);  // Fondo cian
        closeButton.setForeground(Color.BLACK); // Texto negro
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.addActionListener(e -> this.dispose()); // Cerrar ventana de créditos
        panel.add(closeButton);

        // Agregar panel a la ventana
        add(panel);

        // Hacer visible la ventana
        setVisible(true);
    }
}
