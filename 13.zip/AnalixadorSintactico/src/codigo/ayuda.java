package codigo;  

import javax.swing.*;
import java.awt.*;

public class ayuda extends JFrame {

    public ayuda() {
        // Configurar la ventana de ayuda
        setTitle("Ventana de Ayuda");
        setSize(400, 300);
        setLocationRelativeTo(null); // Centra la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Crear un panel con un layout adecuado
        JPanel panel = new JPanel();
        panel.setBackground(Color.BLACK);  // Fondo negro
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));  // Layout de caja vertical

        // Título en cian
        JLabel title = new JLabel("Bienvenido a la Ayuda", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(Color.CYAN);
        panel.add(title);

        // Texto de ayuda
        JTextArea helpText = new JTextArea();
        helpText.setText("Aquí puedes encontrar toda la información que necesitas.\n" +
                         "1. ¿Cómo usar la aplicación?\n colocas el codigo que estas programando"
                + "en español y lo que hara este aplicacion es revisar tus errores" +
                         "2. Solución de problemas.\n en caso de contar con algun problema revisa tu codigo quizas"
                + "tenga algun error no conocido");
        helpText.setBackground(Color.BLACK);  // Fondo negro
        helpText.setForeground(Color.CYAN);   // Texto en cian
        helpText.setFont(new Font("Arial", Font.PLAIN, 14));
        helpText.setEditable(false);          // No editable
        helpText.setLineWrap(true);           // Ajuste de línea
        helpText.setWrapStyleWord(true);      // Ajuste por palabra
        JScrollPane scrollPane = new JScrollPane(helpText);  // Panel de desplazamiento
        panel.add(scrollPane);

        // Botón de cerrar
        JButton closeButton = new JButton("Cerrar");
        closeButton.setBackground(Color.CYAN);  // Fondo cian
        closeButton.setForeground(Color.BLACK); // Texto negro
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.addActionListener(e -> this.dispose()); // Cerrar ventana de ayuda
        panel.add(closeButton);

        // Agregar panel a la ventana
        add(panel);

        // Hacer visible la ventana
        setVisible(true);
    }
}
