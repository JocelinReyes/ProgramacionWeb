package com.tesji.practicaspinner;

import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.tesji.practicaspinner.model.CarrerasModel;
public class MainActivity extends AppCompatActivity {
private Spinner spCarreras;
public Button btnVerCarrera;
private TextView tvImprimir;
String[] opCarreras = {
        "--Seleccione Carreras--",
        "Ing Industrial",
        "Ing Sistemas Computacionales",
        "Ing Logistica",
        "Ing Civil",
        "Ing Mecatronica",
        "Ing TICs",
        "Lic Administracion",
        "Ing Quimica"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        spCarreras = findViewById(R.id.sppinnerCarreras);
        btnVerCarrera = findViewById(R.id.bMostrar);
        tvImprimir = findViewById(R.id.textViewImprimir);
        ArrayAdapter<String> adapCarreras = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,opCarreras);
        spCarreras.setAdapter(adapCarreras);

        btnVerCarrera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                CarrerasModel carrera = new CarrerasModel();
                carrera.setCarrera(spCarreras.getSelectedItemPosition());
                tvImprimir.setText(carrera.mostrarInfo());
            }
        });
    }
}