package com.tesji.practicaspinner.model;

public class CarrerasModel {
    private int carrera;

    public String mostrarInfo() {
        String infoCarrera = "";

        switch (carrera) {
            case 0:
                infoCarrera = "Por favor, seleccione carrera";
                break;
            case 1:
                infoCarrera = "Ingenieria Industrial te permite...";
                break;
            case 2:
                infoCarrera = "Ing Sistemas, es una carrera donde podras desarrollar doftware, diseño, admon de redes y base de datos";
                break;
            case 3:
                infoCarrera = "Ing logistica permite trazar la mejor ruta de entrga de productos";
                break;
            case 4:
                infoCarrera = "Ing Civil permite hacer puentes";
                break;
            case 5:
                infoCarrera = "Ing Mecatronica permite hacer robots";
                break;
        }
        return infoCarrera;
    }

    public int getCarrera() {
        return carrera;
    }

    public void setCarrera(int carrera) {
        this.carrera = carrera;
    }


}
